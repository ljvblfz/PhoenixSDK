//-----------------------------------------------------------------------------
//
// Description:
//
//   Enter your phase description here
//
// Remarks:
//
//    Registers the "$safeprojectname$" phase plugin 
//          component control.
//
//-----------------------------------------------------------------------------
using System;

namespace $safeprojectname$
{
    //-------------------------------------------------------------------------
    //
    // Description:
    //
    //    A compiler phase.
    //
    // Remarks:
    //
    //    Each phase must implement two methods: New and Execute.  New, a
    //    static method, should initialize any phase controls and return a new
    //    instance of the phase.  Execute is responsible for performing the
    //    actual work of the phase.
    //
    //-------------------------------------------------------------------------

    public class Phase : Phx.Phases.Phase
    {

#if PHX_DEBUG_SUPPORT
   
        static public Phx.Controls.ComponentControl $safeprojectname$Control;

#endif

        //---------------------------------------------------------------------
        //
        // Description:
        //
        //    New creates an instance of a phase.  Following Phoenix guidelines
        //    New is static.
        //
        // Arguments:
        //
        //    config - [in] A Phases.PhaseConfiguration that provides properties for 
        //          retrieving the initial phase list
        //
        // Returns:
        //
        //    The new phase.
        //
        //---------------------------------------------------------------------

        static public Phase New(Phx.Phases.PhaseConfiguration config)
        {
            Phase phase = new Phase();

            phase.Initialize(config, "Enter your phase description here");

#if PHX_DEBUG_SUPPORT

            phase.PhaseControl = Phase.$safeprojectname$Control;

#endif

            return phase;
        }

        //---------------------------------------------------------------------
        //
        // Description:
        //
        //    Execute is the phase's prime mover; all unit-centric processing 
        //    occurs here.  Note that Execute might be thought of as a 
        //    "callback": as the C2 host compiles each FunctionUnit, passing it 
        //    from phase to phase, the plug-in Execute method is called to do 
        //    its work.
        //
        // Arguments:
        //
        //    unit - [in] The unit to process.
        //
        // Remarks:
        //
        //    Since IR exists only at the FunctionUnit level, we ignore 
        //    ModuleUnits.
        //
        //    The order of units in a compiland passed to Execute is 
        //    indeterminate.
        //
        //---------------------------------------------------------------------

        protected override void Execute(Phx.Unit unit)
        {
            if (!unit.IsFunctionUnit)
            {
                return;
            }

            Phx.FunctionUnit functionUnit = unit.AsFunctionUnit;

            //TODO: Insert your phase logic here

            // This example loop iterates through all the instructions in the
            // intermediate representation of the FunctionUnit.

            foreach (Phx.IR.Instruction instruction in Phx.IR.Instruction.Iterator(functionUnit))
            {
            }
        }
    }

    //-------------------------------------------------------------------------
    //
    // Description:
    //
    //    Class designed to interface our phase with a Phoenix-based compiler.
    //
    // Remarks:
    //
    //    To interface with a Phoenix based compiler, a DLL contains a class
    //    derived from Phx.PlugIn.  This class must implement two methods:
    //    RegisterObjects and BuildPhases.  RegisterObjects is called when the
    //    plug-in is loaded and is responsible for registering any component
    //    controls the plug-in might need.  BuildPhases is responsible for
    //    modifying the phase list of the compiler, perhaps including a new 
    //    phase or replacing an existing one.
    //
    //-------------------------------------------------------------------------

    public class PlugIn : Phx.PlugIn
    {
        //---------------------------------------------------------------------
        //
        // Description:
        //
        //    RegisterObjects initializes the plug-in's environment.  Normally,
        //    this includes defining your command-line switches (controls) that 
        //    should be handled by Phoenix.  Phoenix calls this method early, 
        //    upon loading the plug-in's DLL.
        //
        // Remarks:
        //
        //    The RegisterObjects method is not the place to deal with 
        //    phase-specific issues, because the host has not yet built its 
        //    phase list. However, controls ARE phase-specific.  Because your 
        //    phase object does not exist yet, your phase's controls must be 
        //    static fields, accessible from here.
        //
        //---------------------------------------------------------------------
        public override void RegisterObjects()
        {

#if PHX_DEBUG_SUPPORT

            Phase.$safeprojectname$Control =
                Phx.Controls.ComponentControl.New("$safeprojectname$",
                    "Enter your phase description here",
                    "c2phase.cs");
#endif
        }

        //---------------------------------------------------------------------
        //
        // Description:
        //
        //    BuildPhases is where the plug-in creates and initializes its 
        //    phase object(s)  and inserts them into 
        //    the phase list already created by the c2 host.
        //
        // Arguments:
        //
        //    config - [in] A Phases.PhaseConfiguration that provides
        //          properties for retrieving the initial phase list
        //
        // Remarks:
        //
        //    Your plug-in determines a new phase's place in the list by 
        //    locating an existing phase by name and inserting the new phase 
        //    before or after it. A phase is created by its static New method.  
        //    One may place the insertion code here in BuildPhases, or delegate 
        //    it to the phase's New method. Phoenix places few requirements on 
        //    phase construction, so you are free to choose the most reasonable 
        //    approach for your needs.
        //
        //    Since we are inserting multiple instances of this phase, we'll 
        //    build their names from the name of the phases they follow.
        //
        //    The Phoenix framework has parsed the command line, so control 
        //    values are available at this point.
		//
		//    Below are listed the phase names that are executed by default during an optimized compilation.
		//    Choose the phase that you would like yours to run after and replace
		//    '<Existing phase you would like your phase to run after>' with its name.
		//
		//    *** C2 Pass0 Phases ***
        //       *** Pass0 Pre-compilation phases ***
        //          CxxIL Reader
        //          Add CallGraph Call Site Information
        //       *** Pass0 Compilation phases ***
        //       *** Pass0 Post-compilation phases ***
        //    *** C2 NativePhases ***
        //       *** Pre-compilation phases ***
        //          CxxIL Reader
        //          Add CallGraph Call Site Information
        //          Warnings Analysis Phase
        //          Unreachable code removal phase
        //          Inliner
        //       *** Compilation phases ***
        //          Type Checker
        //          *** LIR Phases ***
        //             OpenMP
        //             Alias analysis
        //             Flow Optimization
        //             MIR Lower
        //             Simple RegisterVariableDetection
        //             Loop recognition and loop transformations
        //             Global optimization
        //             Loop optimizations
        //             GS Strict
        //             GS Shadow Copying
        //             GS Security Cookie Allocation
        //             Profile Instrumentation Phase
        //             X86 scalar Sse
        //             Canonicalize
        //             ShiftExpansion Strength Reduction
        //             Address Mode Builder
        //             Dynamic Initializer Optimization Phase
        //             Lower
        //             Lir SSA-based idioms optimization phase
        //             Priority Order Register Allocation
        //             X87 Stack Allocation
        //             Lir Sequential idioms optimization phase
        //             GS Security Cookie Initialization and Check
        //             Native EH Lower
        //             Stack Packer
        //             Frame Generation
        //             Switch Lower
        //             Dead Stores
        //             Block Layout
        //             Flow Optimization
        //             Finish EH Lower
        //             Encoding
        //             Call Graph Info Propagation Phase
        //       *** Post-compilation phases ***
        //          Emission
        //          Emit Referenced Symbols
        //          Assembly Listing
        //
        //---------------------------------------------------------------------

        public override void BuildPhases(Phx.Phases.PhaseConfiguration config)
        {
            Phx.Phases.Phase basePhase;

            // InsertAfter CxxIL Reader

            basePhase = config.PhaseList.FindByName("<Existing phase you would like your phase to run after>");
            if (basePhase == null)
            {
                Phx.Output.WriteLine("<Existing phase you would like your phase to run after> phase " +
                    "not found in phaselist:");
                Phx.Output.Write(config.ToString());

                return;
            }

            Phx.Phases.Phase phase = Phase.New(config);
            basePhase.InsertAfter(phase);
        }


        //---------------------------------------------------------------------
        //
        // Description:
        //
        //    Returns the name of your plugin
        //
        //---------------------------------------------------------------------

        public override string NameString
        {
            get { return "$safeprojectname$"; }
        }
    }
}
