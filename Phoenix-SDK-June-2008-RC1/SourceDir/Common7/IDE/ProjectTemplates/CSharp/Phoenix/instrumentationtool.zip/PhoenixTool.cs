//-----------------------------------------------------------------------------
//
// Description:
//
//    A standalone static analysis/instrumentation tool
//
// Usage:
//
//    $safeprojectname$ /out <filename> /pdbout <filename>
//    /in <image-name>
//
//-----------------------------------------------------------------------------

#region Using namespace declarations

using System;
using System.IO;
using System.Collections;

#endregion

namespace $safeprojectname$
{
    //-------------------------------------------------------------------------
    //
    // Description:
    //
    //    This class is responsible for the instrumentation of each method.
    //
    //-------------------------------------------------------------------------

    public class InstrumentPhase : Phx.Phases.Phase
    {
#if PHX_DEBUG_SUPPORT
        private static Phx.Controls.ComponentControl InstrumentPhaseControl;
#endif

        //---------------------------------------------------------------------
        //
        // Description:
        //
        //    Initialize the instrumentation phase.
        //
        // Remarks:
        //
        //    Sets up a component control under debug builds, so that we
        //    can dump IR before/after the phase and so on. In other
        //    words, because we create this control, you can pass in
        //    options like -predumpmtrace that will dump the IR for each
        //    method before this phase runs.
        //
        //---------------------------------------------------------------------
        public static void Initialize()
        {
#if PHX_DEBUG_SUPPORT
            InstrumentPhase.InstrumentPhaseControl = Phx.Controls.ComponentControl.New("root",
                "Inject instrumentation", "PhoenixTool.cs");
#endif
        }

        //---------------------------------------------------------------------
        //
        // Description:
        //
        //    Create a new InstrumentationPhase object.
        //
        // Arguments:
        //
        //    config - The encapsulating object that simplifies handling of
        //    the phase list and pre and post phase events.
        //
        // Returns:
        //
        //    A new InstrumentationPhase object.
        //
        //---------------------------------------------------------------------
        public static InstrumentPhase New(Phx.Phases.PhaseConfiguration config)
        {
            InstrumentPhase instrumentPhase = new InstrumentPhase();

            instrumentPhase.Initialize(config,
                "$safeprojectname$ instrumentation phase");

#if PHX_DEBUG_SUPPORT
            instrumentPhase.PhaseControl = InstrumentPhase.InstrumentPhaseControl;
#endif

            return instrumentPhase;
        }

        //---------------------------------------------------------------------
        // 
        // Description:
        //
        //    Instrument a particular function.
        //
        // Arguments:
        //
        //    unit - The unit this phase is operating on.
        //
        // Remarks:
        //
        //    Insert your instrumentation code here.  For more information on
        //    adding instrumentation code to a binary, please see the samples
        //    readme file.
        //
        //---------------------------------------------------------------------
        protected override void Execute(Phx.Unit unit)
        {
            if (!unit.IsFunctionUnit)
            {
                return;
            }
            Phx.FunctionUnit functionUnit = unit.AsFunctionUnit;

            // TODO: Do your instrumentation code of this unit here
        }
    }

    //-------------------------------------------------------------------------
    //
    // Description:
    //
    //    Encode the modified function.
    //
    // Remarks:
    //
    //    This phase produces encoded binary instructions from the
    //    Phoenix IR.
    //
    //-------------------------------------------------------------------------
    public class EncodePhase : Phx.Phases.Phase
    {
        //---------------------------------------------------------------------
        //
        // Description:
        //
        //    Creates a new EncodePhase object
        //
        // Arguments:
        //
        //    config - The encapsulating object that simplifies handling of
        //    the phase list and pre and post phase events.
        //
        //---------------------------------------------------------------------
        public static EncodePhase New(Phx.Phases.PhaseConfiguration config)
        {
            EncodePhase encodePhase = new EncodePhase();

            encodePhase.Initialize(config, "Encode");

            return encodePhase;
        }

        //---------------------------------------------------------------------
        //
        // Description:
        //
        //    Executes the EncodePhase phase.
        //
        // Arguments:
        //
        //    unit - The unit that this phase should operate on.
        //
        // Remarks:
        //
        //    This phase encodes the IR of the unit to ready it for writing.  
        //    Most instrumentation tools will probably not need to modify this 
        //    phase.
        //
        //---------------------------------------------------------------------
        protected override void Execute(Phx.Unit unit)
        {
            Phx.PE.Writer.EncodeUnit(unit);
        }
    }

    //-------------------------------------------------------------------------
    //
    // Description:
    //
    //    Emit the modified binary...
    //
    // Remarks:
    //
    //    This phase writes out the instrumented binary.
    //
    //-------------------------------------------------------------------------
    public class EmitPhase : Phx.Phases.Phase
    {

        //---------------------------------------------------------------------
        //
        // Description:
        //
        //    Creates a new EmitPhase object
        //
        // Arguments:
        //
        //    config - The encapsulating object that simplifies handling of
        //    the phase list and pre and post phase events.
        //
        //---------------------------------------------------------------------
        public static EmitPhase New(Phx.Phases.PhaseConfiguration config)
        {
            EmitPhase emitPhase = new EmitPhase();

            emitPhase.Initialize(config, "Emit");

            return emitPhase;
        }

        //---------------------------------------------------------------------
        //
        // Description:
        //
        //    Executes the EmitPhase phase.
        //
        // Arguments:
        //
        //    unit - The unit that this phase should operate on.
        //
        // Remarks:
        //
        //    Emits the final modified PE, complete with a new pdb.
        //
        //---------------------------------------------------------------------
        protected override void Execute(Phx.Unit unit)
        {
            if (!unit.IsPEModuleUnit)
            {
                return;
            }

            Phx.PEModuleUnit peModule = unit.AsPEModuleUnit;

            // Retrieve the names of the input and output files for the tool.

            String inputFileNameStr = Driver.input.GetValue(null);
            String outputFileNameString = Driver.output.GetValue(null);
            String outputPdbFileNameStr = Driver.pdbout.GetValue(null);

            Phx.Output.WriteLine("...writing to " + outputFileNameString);

            // Initialize a new PE writer.

            Phx.PE.Writer writer = Phx.PE.Writer.New(
                Phx.GlobalData.GlobalLifetime, outputFileNameString,
                outputPdbFileNameStr, peModule, peModule.SymbolTable,
                peModule.Architecture, peModule.Runtime);

            writer.Write();
        }
    }


    public class Driver
    {
        //---------------------------------------------------------------------
        //
        // Description:
        //
        //    Name of the executable file to process.
        //
        //---------------------------------------------------------------------
        public static Phx.Controls.StringControl input;

        //---------------------------------------------------------------------
        //
        // Description:
        //
        //    Name of the output binary.
        //
        //---------------------------------------------------------------------
        public static Phx.Controls.StringControl output;

        //---------------------------------------------------------------------
        //
        // Description:
        //
        //    Name of the output pdb.
        //
        //---------------------------------------------------------------------
        public static Phx.Controls.StringControl pdbout;

        //---------------------------------------------------------------------
        //
        // Description:
        //
        //    Does the static initialization of the Phoenix framework and the 
        //    program.
        //
        // Arguments:
        //
        //    arguments - Array of command line argument strings.
        //
        // Remarks:
        //
        //    StaticInitialize registers the available targets and processes in the 
        //    command-line options.
        //
        //---------------------------------------------------------------------
        public static void StaticInitialize(string[] arguments)
        {
            // Initialize the available targets.

            Driver.InitializeTargets();

            // Start initialization of the Phoenix framework.

            Phx.Initialize.BeginInitialization();

            // Initialize the command line string controls

            Driver.InitializeCommandLine();

            // Initialize the component control for the instrumentation phase.
            // This is included so that standard Phoenix controls can be used 
            // on this too.

            InstrumentPhase.Initialize();

            Phx.Initialize.EndInitialization("PHX|*|_PHX_", arguments);

            // Check the processed command line options against those required
            // by the tool for execution.  If they are not present, exit the 
            // app.

            if (!Driver.CheckCommandLine())
            {
                Driver.Usage();
                Phx.Term.All(Phx.Term.Mode.Fatal);
                Environment.Exit(1);
            }
        }

        //---------------------------------------------------------------------
        //
        // Description:
        //
        //    Usage string for this sample.
        //
        // Remarks:
        //
        //    Options can include any of the standard phoenix controls,
        //    eg -dumptypes.
        //
        //---------------------------------------------------------------------
        public static void Usage()
        {
            Phx.Output.WriteLine("$safeprojectname$ /out <filename> " +
    "/pdbout <filename> /in <image-name>");
        }

        //---------------------------------------------------------------------
        //
        // Description:
        //
        //    Checks the command line against the required options.
        //
        // Returns:
        //
        //    True if the command line has all the required options, false 
        //    otherwise.
        //
        //---------------------------------------------------------------------
        private static bool CheckCommandLine()
        {
            return !(String.IsNullOrEmpty(Driver.input.GetValue(null))
    || String.IsNullOrEmpty(Driver.output.GetValue(null))
    || String.IsNullOrEmpty(Driver.pdbout.GetValue(null)));
        }

        //---------------------------------------------------------------------
        //
        // Description:
        //
        //    Registers string controls with Phoenix for command line option
        //    processing.
        //
        //---------------------------------------------------------------------
        private static void InitializeCommandLine()
        {
            // Initialize each command line option (string controls), so that
            // the framework knows about them.
            Driver.input = Phx.Controls.StringControl.New("in", "input file",
                Phx.Controls.Control.MakeFileLineLocationString("PhoenixTool.cs", 387));
            Driver.output = Phx.Controls.StringControl.New("out", "output file", 
                Phx.Controls.Control.MakeFileLineLocationString("PhoenixTool.cs", 389));
            Driver.pdbout = Phx.Controls.StringControl.New("pdbout", "output pdb file",
                Phx.Controls.Control.MakeFileLineLocationString("PhoenixTool.cs", 391));
        }

        //---------------------------------------------------------------------
        //
        // Description:
        //
        //    Initialize the dependent architectures and runtimes.
        //
        // Remarks:
        //
        //    All runtimes and architectures available in the RDK are 
        //    registered.
        //
        //---------------------------------------------------------------------
        private static void InitializeTargets()
        {
            // Setup targets available in the RDK.

            Phx.Targets.Architectures.Architecture x86Arch =
                Phx.Targets.Architectures.X86.Architecture.New();
            Phx.Targets.Runtimes.Runtime win32x86Runtime =
                Phx.Targets.Runtimes.Vccrt.Win32.X86.Runtime.New(x86Arch);
            Phx.GlobalData.RegisterTargetArchitecture(x86Arch);
            Phx.GlobalData.RegisterTargetRuntime(win32x86Runtime);

            Phx.Targets.Architectures.Architecture msilArch =
                Phx.Targets.Architectures.Msil.Architecture.New();
            Phx.Targets.Runtimes.Runtime win32MSILRuntime =
                Phx.Targets.Runtimes.Vccrt.Win.Msil.Runtime.New(msilArch);
            Phx.GlobalData.RegisterTargetArchitecture(msilArch);
            Phx.GlobalData.RegisterTargetRuntime(win32MSILRuntime);
        }

        //---------------------------------------------------------------------
        //
        // Description:
        //
        //    Process the module.
        //
        // Remarks:
        //
        //    The launch point for the instrumentation/static analysis 
        //    functionality of the tool.  Process first opens the existing  
        //    binary and determines its target architecture and runtime.  Then, 
        //    it creates a PE module unit with the input binary and a phase  
        //    listing.  The phase listing is then executed on the PE module.
        //
        //---------------------------------------------------------------------
        public Phx.Term.Mode Process()
        {
            Phx.Output.WriteLine("Processing " +
                Driver.input.GetValue(null) + " ...");

            // Lookup the architecture and runtime from the existing assembly.

            Phx.PEModuleUnit oldModuleUnit =
                Phx.PEModuleUnit.Open(Driver.input.GetValue(null));

            Phx.Targets.Architectures.Architecture architecture = oldModuleUnit.Architecture;
            Phx.Targets.Runtimes.Runtime runtime = oldModuleUnit.Runtime;

            oldModuleUnit.Close();
            oldModuleUnit.Delete();

            // Create an empty program unit

            Phx.Lifetime lifetime =
                Phx.Lifetime.New(Phx.LifetimeKind.Global, null);

            Phx.ProgramUnit programUnit = Phx.ProgramUnit.New(lifetime, null,
                Phx.GlobalData.TypeTable, architecture, runtime);

            // Make an empty moduleUnit

            Phx.PEModuleUnit moduleUnit = Phx.PEModuleUnit.New(lifetime,
                Phx.Name.New(lifetime, Driver.input.GetValue(null)),
                programUnit, Phx.GlobalData.TypeTable, architecture, runtime);

            // Create an overall phase list....

            Phx.Phases.PhaseConfiguration config = Phx.Phases.PhaseConfiguration.New(
                lifetime, "$safeprojectname$ Phases");

            // Add phases...

            config.PhaseList.AppendPhase(Phx.PE.ReaderPhase.New(config));

            // Create the per-function phase list....

            Phx.Phases.PhaseList unitList = Phx.PE.UnitListPhaseList.New(
                config, Phx.PE.UnitListWalkOrder.PrePass);

            unitList.AppendPhase(
                Phx.PE.RaiseIRPhase.New(config,
                    Phx.FunctionUnit.LowLevelIRBeforeLayoutFunctionUnitState));

            unitList.AppendPhase(InstrumentPhase.New(config));
            unitList.AppendPhase(EncodePhase.New(config));
            unitList.AppendPhase(Phx.PE.DiscardIRPhase.New(config));

            config.PhaseList.AppendPhase(unitList);

            config.PhaseList.AppendPhase(EmitPhase.New(config));

            // Add any plugins or target-specific phases.

            Phx.GlobalData.BuildPlugInPhases(config);

            // Run the phases.

            config.PhaseList.DoPhaseList(moduleUnit);

            return Phx.Term.Mode.Normal;
        }

        //---------------------------------------------------------------------
        //
        // Description:
        //
        //    Entry point for application
        //
        // Arguments:
        //
        //    argument - Command line argument strings.
        //
        //---------------------------------------------------------------------
        static int Main(string[] arguments)
        {
            // Do static initialization of the Phoenix framework.

            Driver.StaticInitialize(arguments);

            // Process the binary.

            Driver driver = new Driver();
            Phx.Term.Mode termMode = driver.Process();

            Phx.Term.All(termMode);
            return (termMode == Phx.Term.Mode.Normal ? 0 : 1);
        }
    }
}
